# Reglas de diagramación

> **Estándar vigente (v2):** el diagrama se genera con `scripts/generar_diagrama.py` (SVG → PDF/PNG,
> más BPMN 2.0). Las secciones de abajo marcadas **[Mermaid]** solo aplican si, excepcionalmente,
> se usa Mermaid como alternativa de reserva. Todo lo demás aplica siempre.

## Estructura por defecto

- **Carriles horizontales** por responsable, dentro de un pool con el nombre del procedimiento
  (texto vertical a la izquierda). Orden de carriles = orden de aparición en el cuadro.
- **Fases** = bandas verticales con encabezado arriba y línea punteada entre bandas, **solo si la
  fuente las define** (filas de una celda combinada en el cuadro). Alternancia de fondo muy suave
  entre bandas. Nunca inferir fases de menciones sueltas.
- Flujo de izquierda a derecha. Una columna por paso, salvo que **dos pasos consecutivos del
  mismo responsable y la misma fase se apilan** en una columna (flecha vertical corta entre ellos)
  para no ensanchar el diagrama. El apilado se desactiva cuando hay decisiones (modo manual).
- **Una sola flecha por hueco entre columnas** → no hay cruces. El codo de una flecha entre
  carriles se ubica al 30 % del hueco (no en el centro, para no coincidir con el separador de fase).
- Punto de validación en la esquina superior derecha de cada actividad/decisión.

## Contenido de la caja

- Solo **número de la fuente + actividad**. El responsable lo da el carril.
- **Se descartan**: FRECUENCIA, EVIDENCIA O SOPORTE, ACTIVIDAD DE CONTROL (salvo petición), nombres
  y códigos de formatos (F04-GRI, FR-006-GRI), referencias normativas, nombres de aplicativos
  secundarios, plazos secundarios, notas aclaratorias y el **título en mayúsculas** que algunas
  actividades traen como encabezado ("EGRESO DE LA RUTA:"). Lo omitido que importe se anota en la
  nota de validación del paso.
- Erratas de la fuente ("Riego", "primera de línea", "de 216"): en la caja se escribe bien; en la
  nota se avisa (amarillo).

## Decisiones, ramas y finales

- **Rombo solo si la fuente define la bifurcación** (pregunta + salidas). Etiquetas de salida
  cortas: "Sí" / "No" (o la opción real). La pregunta va **encima** del rombo, con el número.
- **Decisión implícita** ("en caso de desviaciones...", "definir cumplimiento de metas...") sin rama
  definida en la fuente → **actividad plana + nota amarilla** que diga qué falta. No se inventa el "No".
- **Retorno** ("regresar a la actividad N") → flecha de **retorno**: baja del rombo a un canal bajo
  el carril, va hasta la columna del destino y entra por **abajo** de la caja destino.
- **Rama corta** (p. ej. "informar no coincidencia y continuar"): va en una fila inferior del mismo
  carril, con su propio evento Fin. **Varios eventos Fin son válidos** y evitan cruces; si la
  fuente no dice que el procedimiento termina ahí, se asume Fin y se marca amarillo.
- Toda rama termina en un Fin o reconecta al flujo. Nada colgando.
- Dos pasos "hermanos" para poblaciones/casos distintos (p. ej. 5 y 6) que la fuente no relaciona:
  se dejan en secuencia y se marca amarillo ("¿paralelos o alternativos?").

## Límite de 100 caracteres (regla del encargo)

- Toda **actividad** o **acción** ≤ **100 caracteres**, contando espacios.
- Si no cabe: partir en dos pasos, o reescribir más directo. Nunca abreviar con siglas no
  estándar ni recortar hasta que quede ambiguo.
- **Antes de partir un paso en dos, recorta primero.** El párrafo completo de la fuente suele
  incluir referencias que no son la acción en sí — nombre/código de formato, texto de apoyo,
  ejemplos — y esas se descartan del texto de la caja (no se diagraman, no se dividen en un paso
  aparte). Split solo si la frase de acción, YA recortada de esas referencias, sigue sin caber en
  100 caracteres. Confirmado con un procedimiento real: dos pasos se habían partido en dos cajas
  por la longitud del párrafo completo, pero el diagrama real de la organización usaba una sola
  caja para cada uno — la frase de acción sola cabía sobrada.
- Redacción: **verbo en infinitivo + objeto**. "Registrar la solicitud en el sistema", no
  "Registro de solicitud" ni "El analista registra la solicitud que llega...".
- Las **decisiones** se escriben como pregunta cerrada: "¿La solicitud está completa?".
- Las **etiquetas de las salidas** de una decisión: cortas ("Sí" / "No", o la opción real).
- **Numeración de actividades:** toda actividad lleva al inicio de la etiqueta el número del paso
  **tal como aparece en la fuente** (el documento/tabla de donde salió el procedimiento), no una
  renumeración propia — así se puede trazar cada caja del diagrama contra su fila de origen. Si un
  paso original se partió en dos por el límite de 100 caracteres, usa sufijo decimal: paso 6 →
  "6.1", "6.2". Si el insumo no trae numeración propia (ej. texto corrido sin lista), numera
  1, 2, 3... en el orden en que se redactan los pasos (ver `01-flujo-de-trabajo.md`, paso 2).

## Nomenclatura

| Elemento | Cómo se nombra |
|---|---|
| Evento inicial | Sustantivo del disparador: "Solicitud recibida". |
| Actividad | "N. Verbo infinitivo + objeto" — N es el número de la fuente, no uno inventado. ≤ 100 car. |
| Decisión (compuerta) | Pregunta cerrada terminada en "?". |
| Subproceso | Nombre del procedimiento referenciado. |
| Evento final | Resultado alcanzado: "Solicitud archivada". |
| Conector | Número o letra corta: "①", "②"; sin texto descriptivo. |

## Tipos de nodo (equivalencia BPMN / Bizagi)

- **Evento** (círculo): inicio, fin, y esperas/temporizadores si aplica.
- **Actividad** (rectángulo redondeado): un paso de trabajo.
- **Decisión** (rombo): bifurcación exclusiva. Toda rama debe reconectarse o terminar en un fin.
- **Subproceso** (rectángulo con marca +): paso que es en sí otro procedimiento.
- **Cruce entre grupos (responsable o fase): flecha punteada directa, actividad a actividad.**
  Nunca un símbolo que haya que emparejar por número — así el rastro nunca se pierde. Dentro del
  mismo grupo: flecha sólida. Al cambiar de grupo: flecha punteada directa entre esos dos nodos
  concretos. Mismo criterio ya usado para notas de validación ("esto es un salto estructural, no
  una continuación directa").
- **Conector** (círculo pequeño numerado, ver `assets/paleta-bizagi.md`): alternativa de reserva
  poco recomendada, no la opción por defecto. Marca un punto de salida/entrada sin dibujar la
  línea completa. Es la técnica documentada en un export real de Bizagi para el "retorno de
  subsanación" **dentro de un mismo carril sin `subgraph`** (el export real no agrupa por
  responsable con recuadros). Evítala si el diagrama va a tener `subgraph` de por medio — ver
  advertencia debajo.
- **Carril** (*lane*): responsable/rol. **Un responsable es SIEMPRE un solo grupo**, incluso si el
  flujo lo abandona y vuelve más adelante — nunca partir el mismo responsable en dos carriles
  separados.
- **Fase**: banda que agrupa varias actividades por etapa del proceso (no por responsable).

### ⚠️ [Mermaid] `subgraph` (carril o fase) y flechas que cruzan hacia dentro: bug confirmado

**Confirmado con un procedimiento real, en dos intentos distintos:** una flecha (conector numerado
o flecha directa, da igual) hacia un nodo que vive DENTRO de un `subgraph` de Mermaid puede
renderizarse terminando visualmente en el borde del clúster, no en el nodo — el usuario lo vio dos
veces seguidas con técnicas de flecha distintas, y solo se resolvió al quitar el `subgraph` por
completo. Es un límite de Mermaid/dagre con grafos compuestos, no un error de sintaxis.

- **Si el diagrama va a tener cruces frecuentes entre responsables/fases** (más de 1 o 2): **no
  uses `subgraph` en absoluto.** Una sola cadena de cajas en el orden real de ejecución; el
  responsable o la fase de cada paso va como segunda línea de texto dentro de la propia caja
  ("👤 Responsable" o "📍 Fase", con `<br/>`) — esa línea es metadata, no cuenta para el límite de
  100 caracteres de la acción. Cada flecha conecta dos vecinos directos en la cadena, sin
  geometría de clúster de por medio, así que no puede fallar de esta forma. Ver
  `pruebas/documentacion-software/documentacion-software.mmd` (v4/v5) como ejemplo real
  reconstruido tras el bug, y la plantilla "sin agrupación" en `assets/plantilla.mmd`.
- **Si los cruces van a ser raros o el procedimiento es mayormente lineal dentro de cada grupo**,
  sí puedes usar `subgraph` de carril o fase (ver más abajo) — el riesgo es menor cuando hay pocas
  flechas cruzando hacia dentro de un clúster.
- Para armar un carril de todos modos: declarar cada nodo una vez fuera de cualquier `subgraph` y,
  dentro del `subgraph` del carril, solo referenciar su id (ver `assets/plantilla.mmd`).

### ⚠️ [Mermaid] Etiquetas y flechas rotas: "se ve el código, no el diagrama" — bug confirmado

**Confirmado con `fix.md`:** el usuario pegó el `.mmd` generado en Claude Desktop y, en vez del
diagrama, salió el código en texto plano — señal de que el parser de Mermaid no pudo leer el
archivo. Se encontraron dos desviaciones de la sintaxis frente a `assets/plantilla.mmd` (que sí
está probada), las dos en el mismo archivo:

1. **Salto de línea real (Enter) dentro de una etiqueta entre comillas**, en vez de `<br/>`:

   ```
   ❌  A1["1. Identificar la necesidad...
   👤 Líder/Referente del Proceso Solicitante · 🔄 P"]:::actividad

   ✅  A1["1. Identificar la necesidad...<br/>👤 Líder/Referente del Proceso Solicitante · 🔄 P"]:::actividad
   ```

   Todo el texto de una etiqueta (entre `[`/`{` y `]`/`}`) va en **una sola línea física** del
   archivo. El salto visual dentro de la caja se logra solo con `<br/>` — nunca con Enter.

2. **Mezclar el tipo de flecha al abrir y cerrar una arista con etiqueta**: abrir con `--`
   (sólida) y cerrar con `-.->` (punteada) en la misma arista:

   ```
   ❌  G4 -- "Sí" -.-> A1

   ✅  G4 -.->|"Sí"| A1
   ```

   El tipo de línea de apertura y cierre **debe coincidir siempre**. Para una arista **punteada**
   con etiqueta, usa la forma con barras `-.->|"texto"|` (es la que ya usa `assets/plantilla.mmd`
   en PLANTILLA 2, `G1 -.->|"Sí"| A2` — no inventes la variante `-- "texto" -.->`). Para una
   arista **sólida** con etiqueta, `-- "texto" -->` o `-->|"texto"|` sí son válidas y equivalentes.

- **Regla:** antes de entregar cualquier `.mmd`, revisa que (a) ninguna etiqueta entre comillas
  tenga un salto de línea real — solo `<br/>` — y (b) toda arista con etiqueta abra y cierre con
  el mismo tipo de línea (sólida↔sólida, punteada↔punteada). Un solo carácter mal puesto aquí
  hace que Mermaid no renderice nada y el cliente (Claude Desktop/claude.ai) muestre el código
  crudo en vez del diagrama — no es un problema del cliente, es sintaxis inválida.
- Antes de entregar, relee el `.mmd` completo línea por línea contra esta regla; no asumas que
  quedó bien solo porque siguió el patrón de la plantilla en las primeras cajas.
- Ver `fix.md` para el caso real completo (roto y corregido).

### [Mermaid] Agrupación primaria (solo si decidiste usar `subgraph`): ¿fase o carril?

Mermaid no permite anidar carriles y fases de forma legible (dos niveles de `subgraph` con
`direction` propia es frágil) — hay que elegir **uno solo** como la agrupación que estructura el
diagrama, y mostrar el otro como dato dentro de cada caja en vez de como agrupador visual.

- **Agrupa por CARRIL** cuando los responsables son la forma natural de leer el proceso.
- **Agrupa por FASE solo si la fuente las define explícitamente** (encabezado de sección propio,
  columna de fase en la tabla, o similar) — nunca las infieras de indicios débiles como una palabra
  suelta entre paréntesis dentro de la celda de una actividad. Un intento real infirió fases de
  ese tipo de menciones y el usuario las rechazó: ese procedimiento no tenía fases, solo
  responsables.
- Estilo: carril usa la fila "Carril — encabezado" de `assets/paleta-bizagi.md`; fase usa la fila
  "Fase — banda" (deliberadamente otro gris, para que un lector note que es otro tipo de
  agrupación).

## Layout (reglas generales)

- Dirección principal: izquierda → derecha.
- Sin cruces de líneas cuando se pueda evitar; usar ruteo ortogonal.
- Una sola entrada y una sola salida por actividad (las múltiples salidas van por decisión).
- Todas las ramas de una decisión terminan (en un fin o reconectando al flujo). No dejar ramas
  colgando.
- Las notas de validación (`03-validacion-por-colores.md`) llevan el número de paso **de la
  fuente** en su propio texto ("Paso 6 — ..."), no solo la línea punteada que las conecta: en un
  carril con muchos nodos, esa línea puede verse ambigua sobre a cuál actividad exacta corresponde.

## Paleta

- Colores por tipo de elemento según `assets/paleta-bizagi.md`.
- El color de relleno indica **tipo de elemento**, no estado. El estado (verde/amarillo/rojo) va
  como **comentario/marca de validación**, no como relleno del nodo — ver `03-validacion-por-colores.md`.

## Herramienta de dibujo

- **Por defecto:** `scripts/generar_diagrama.py` (spec JSON → SVG/PDF/PNG/BPMN). El spec se guarda
  junto al export para poder regenerar.
- Reserva: Mermaid (`flowchart`) con `classDef` de la paleta, o draw.io con la librería BPMN.
