# Flujo de trabajo detallado

## 1. Leer la fuente antes de preguntar

Lo normal es que el usuario suba el procedimiento (`PR-0xx-....doc`) y diga "haz el diagrama".
Todo esto se responde **leyendo el documento**, no preguntando (ver `07-lectura-de-fuentes.md`):

| Dato | De dónde sale |
|---|---|
| Nombre y código | Encabezado del documento (título, proceso, subproceso, CÓDIGO, VERSIÓN). |
| Inicio y fin | ALCANCE + primera y última actividad del cuadro. |
| Responsables → carriles | Columna RESPONSABLE (en orden de aparición). |
| Fases → bandas verticales | Filas de **una sola celda combinada** dentro del cuadro (p. ej. "PLAN DE MANEJO"). |
| Decisiones | Actividades redactadas como pregunta ("¿...?") con salidas Sí/No; textos "Si..., continuar con la actividad N". |
| Retornos | "regresar a la actividad N", "devolver al responsable". |
| Variaciones | Pasos que cambian según entidad/caso (ver `04-...`). |

## 2. Cuándo SÍ preguntar

Solo si tras leer hay ambigüedad real que cambia el diagrama. Regla: **decidir con lo que dice el
cuadro, avisar, y ofrecer la alternativa en una sola pregunta al final del mensaje**.

- Títulos en negrita dentro de actividades (p. ej. "EGRESO DE LA RUTA") que podrían ser fases pero
  no son filas de encabezado → se usan las fases del cuadro y se ofrece separarlas.
- Formato de entrega: por defecto PDF + PNG + SVG; BPMN si lo piden.
- Si el procedimiento tiene variaciones y no es claro cuáles.

Si el usuario ya dio la estructura ("fases verticales, responsables en carriles horizontales",
"sin evidencias ni frecuencias"), se aplica tal cual.

## 3. Redacción de los pasos

- Un paso del cuadro = una caja, con **su número de la fuente**.
- ≤ 100 caracteres, en infinitivo (`02-reglas-de-diagramacion.md`). Recortar primero; partir en
  N.1/N.2 solo si la acción ya recortada no cabe.
- Anotar en la **nota de validación** lo omitido que importe (plazos, formatos, normas, datos).
- Cada paso lleva estado + nota si es amarillo/rojo.

## 4. Construcción

- Escribir el spec JSON y correr el generador (`06-generador-y-spec.md`).
- Sin decisiones ni ramas → **modo automático** (secuencia por numeración; pasos consecutivos del
  mismo responsable y fase se apilan de a dos para no ensanchar el diagrama).
- Con decisiones o ramas → **modo manual** (`col`/`fila` por paso + `flujos` con etiquetas).
- Con variaciones → general + un spec por variación.

## 5. Revisión visual (obligatoria)

Recortar el PNG en 2-3 tramos y mirarlos: texto dentro de la caja, flechas que tocan cajas,
Sí/No legibles, pregunta del rombo sin chocar con la línea del carril, nada cruzado, punto de
validación visible. Corregir el spec y regenerar.

## 6. Entrega

- `present_files`: PDF, PNG, SVG (+ `.bpmn` si lo pidieron).
- Mensaje corto: estructura, tabla de validación **solo no verdes**, observaciones de la fuente,
  una pregunta de decisión pendiente. Sin volver a explicar todo el diagrama.
