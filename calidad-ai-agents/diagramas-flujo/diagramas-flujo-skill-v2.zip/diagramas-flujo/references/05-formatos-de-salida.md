# Formatos de salida

## Por defecto

`python3 scripts/generar_diagrama.py spec.json --salida /mnt/user-data/outputs` genera:

| Archivo | Para qué |
|---|---|
| `<CODIGO>-diagrama-flujo.pdf` | Vectorial; adjuntar al procedimiento. |
| `<CODIGO>-diagrama-flujo.png` | Incrustar (escala 2x, tope ~9000 px de ancho). |
| `<CODIGO>-diagrama-flujo.svg` | Fuente editable (Inkscape, Illustrator, navegador). |
| `<CODIGO>.bpmn` | BPMN 2.0 con DI (coordenadas): abre en bpmn.io, Camunda Modeler, draw.io, Signavio. |
| `<CODIGO>-validacion.md` | Tabla completa de validación por colores. |

**Se presentan** (`present_files`): PDF + PNG + SVG siempre; `.bpmn` cuando el usuario lo pide
("en BPMN", "cocinamelo en bpmn"). El `.md` no se presenta: su contenido va en el mensaje (solo
no verdes).

## Dependencias

Pillow, cairosvg (`pip install cairosvg --break-system-packages`) y fuentes DejaVu
(`fonts-dejavu`). **Verificado en el sandbox de claude.ai**: no hace falta `mmdc` ni Chromium.

## BPMN

- Carriles = `bpmn:lane`; pool = `bpmn:participant`; decisiones = `exclusiveGateway` (flujo por
  defecto = la salida "No"); fases = `bpmn:group` con `bpmn:category` (BPMN no tiene fases nativas).
- Colores de la paleta como atributos `bioc:` (los usa bpmn.io).
- **Bizagi Modeler no importa BPMN 2.0 estándar** (solo su `.bpm` propietario; probado). Avisarlo
  una vez al entregar el BPMN. Si el destino es Bizagi: abrir el BPMN en otra herramienta y
  redibujarlo en Bizagi con el PNG como guía.
- **Intentos descartados por el usuario**: generar un BPMN en el formato nativo de Bizagi calcado de
  un export real (dos rondas, con y sin grupos de fase). No se conservó; no reintentar sin un export
  de Bizagi donde se vean las fases y sin saber qué se veía mal.
- El BPMN se valida estructuralmente (ids únicos, referencias, `flowNodeRef`), pero no se ha abierto
  en un visor: pedirle al usuario que revise las etiquetas de rombos y grupos la primera vez.

## Múltiples diagramas (variaciones)

Un spec por diagrama: `PROC-general`, `PROC-<variacion>`. Un archivo por diagrama; si quiere un solo
PDF, concatenar al final.

## Calidad

- PNG ≥ 2000 px de ancho o escala 2x. Fondo blanco. Márgenes alrededor.
- El lienzo incluye: título, subtítulo (código · versión · proceso · subproceso), leyenda de
  validación y fecha.

## Reserva: Mermaid

Solo si no hay entorno de código. Bloque ```mermaid``` o Artifact (Mermaid se renderiza nativo).
Aplican las reglas **[Mermaid]** de `02-reglas-de-diagramacion.md` (sin `subgraph` con cruces,
`<br/>` en vez de Enter, aristas con etiqueta de tipo coincidente). Plantilla: `assets/plantilla.mmd`.
