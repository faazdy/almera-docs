# Lectura de la fuente (.doc / .docx)

## Convertir y extraer

```bash
soffice --headless --convert-to docx --outdir work/ /mnt/user-data/uploads/PR-xxx.doc
```
```python
from docx import Document
d = Document("work/PR-xxx.docx")
# encabezado: d.sections[i].header.tables  -> título, proceso, subproceso, CÓDIGO, VERSIÓN
# tablas: OBJETIVO, ALCANCE, DEFINICIONES, MARCO LEGAL, CONDICIONES GENERALES,
#         cuadro de actividades (primera fila 'RESPONSABLE' | 'No.' | 'ACTIVIDAD' | ...),
#         DOCUMENTOS INTERRELACIONADOS, CONTROL DE CAMBIOS, DIAGRAMA DE FLUJO
idx = [i for i,t in enumerate(d.tables) if t.rows[0].cells[0].text.strip() == "RESPONSABLE"][0]
```
Al recorrer las filas del cuadro, **deduplicar celdas combinadas** por `cell._tc`: una fila con **una
sola celda** es un **encabezado de fase** ("PLAN DE MANEJO"); una fila con 6 celdas es una actividad.

## Qué extraer

- Cuadro: RESPONSABLE, No., ACTIVIDAD (se ignoran FRECUENCIA/EVIDENCIA/CONTROL por defecto).
- Fases: filas de una celda (si hay).
- ALCANCE (dónde inicia/termina) y CONDICIONES GENERALES (para detectar etapas que el cuadro no
  trae, p. ej. "actualización anual").
- Negritas dentro de la celda ACTIVIDAD: títulos de sub-etapa (`run.bold`) → se quitan de la caja;
  si parecen fases, ver `01-flujo-de-trabajo.md` §2.

## Ojo con

- **El diagrama incrustado en el .doc suele estar desactualizado** (otros responsables, otros
  pasos). Es solo referencia de estilo; manda el cuadro de actividades de la versión vigente.
  Puede ser solo el logo (`word/media/image1.png`): mirarlo antes de asumir.
- **Cargas duplicadas**: si el usuario sube el mismo procedimiento otra vez, comparar tablas,
  párrafos y tamaño/hash del archivo. Si son idénticos, **decirlo y no rehacer**: re-presentar los
  archivos ya generados y ofrecer las alternativas pendientes.
- **Imagen de referencia de estructura** (a veces se sube un export de Bizagi de otro
  procedimiento): copiar su estructura (carriles, fases, encabezados), no su contenido ni su paleta
  exacta de inicio/fin (ver `assets/paleta-bizagi.md`).
- Erratas y códigos inconsistentes de la fuente → nota amarilla, texto corregido en la caja.
- Cosas del ALCANCE/CONDICIONES que el cuadro no trae → mencionarlas en el mensaje, no diagramarlas.

## Fases con letra (A, B, C…) y numeración que reinicia

Word numera las filas de fase con una **lista automática** (`w:numPr` con `numFmt=upperLetter`): la
letra **no aparece** en `cell.text`. Para detectarla, mirar `numPr`/`numId` en el primer párrafo de las
filas de una celda: las que comparten `numId` y `ilvl=0` son las fases A, B, C… en orden. Una fila
anterior sin numeración (p. ej. "ADMINISTRACION Y CONTROL DE LOS BIENES") es un **título general**, no
una fase. Si los pasos reinician en 1 en cada fase, el id del paso es letra + número (A1, B2…).
