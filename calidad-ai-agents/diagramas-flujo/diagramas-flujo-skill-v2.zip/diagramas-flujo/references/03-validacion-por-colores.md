# Validación por colores

Todo diagrama entregado lleva una capa de validación. Sirve para que quien revisa el
procedimiento vea de un vistazo qué está sólido y qué no.

## Significado

| Color | Significado | Cuándo se usa |
|---|---|---|
| 🟢 Verde | Todo correcto | El paso está claro, es correcto y no requiere acción. |
| 🟡 Amarillo | Parcialmente correcto, requiere revisar | Falta un dato, hay una redacción ambigua, o una suposición que confirmar. |
| 🔴 Rojo | Revisar obligatoriamente | Hay un error, un vacío que rompe el flujo, o contradice otra fuente. |

## Cómo se muestra

1. **Marca en el nodo**: un **punto de color en la esquina superior derecha** de cada actividad y
   decisión (el script lo dibuja), sin cambiar el color de relleno que indica el tipo de elemento.
2. **Tabla de validación** que acompaña al diagrama:

```markdown
| # | Paso | Color | Comentario |
|---|------|-------|------------|
| 3 | ¿La solicitud está completa? | 🟡 | No está definido qué campos son obligatorios. |
| 5 | Notificar al solicitante | 🔴 | No se indica por qué medio ni en qué plazo. |
| 7 | Archivar la solicitud | 🟢 | — |
```

3. **Leyenda** visible en el propio diagrama con los tres colores y su significado.

## Reglas

- Cada paso tiene exactamente un color.
- Amarillo y rojo **siempre** llevan comentario que diga qué revisar. Verde puede ir sin comentario.
- Si hay diagrama general + variaciones, cada diagrama lleva su propia tabla.
- Al re-generar un diagrama tras las correcciones, actualizar los colores (idealmente todo a verde).

## En la práctica (v2)

- En el **spec** cada paso lleva `estado` (verde por defecto) y `nota` (obligatoria si es amarillo o rojo).
- El script escribe `<CODIGO>-validacion.md` con **todos** los pasos; en el **mensaje al usuario** se
  muestra solo la tabla de los pasos **no verdes** (y se dice que el resto quedó en verde).
- En el **BPMN** el comentario de cada amarillo/rojo va en `<bpmn:documentation>` del elemento (se ve
  en el panel de propiedades de bpmn.io); no se dibujan anotaciones para no ensuciar el lienzo.
- Criterios de amarillo que ya se han repetido: errata o código inconsistente en la fuente; referencia
  normativa ilegible; decisión implícita sin rama definida; pasos hermanos sin relación explícita;
  fin de rama asumido; dos pasos que se superponen; actividad que la fuente ubica en una fase pero
  las condiciones generales tratan como etapa aparte.

## Comentarios de revisión en el diagrama (`--comentarios`)

Ejemplo real recibido: `assets/ejemplos-reales/diagrama-ejemplo-comentarios-rev.bpmn` (nota gris
`#D5D5D5` con texto `🔴 Paso 4 — Revisar obligatoriamente: …` / `🟡 Paso 8 — …`, ligada a la tarea con
una asociación).

- **Cuándo**: solo si el usuario lo pide ("ponle comentarios de revisión"). Por defecto el diagrama
  lleva solo el punto de color. Se generan **únicamente** para pasos 🟡 y 🔴.
- **Spec**: campo `comentario` por paso (≤ ~120 caracteres; si falta se usa `nota`). Texto en la nota:
  `Paso <num> — <comentario>`; en el SVG/PDF/PNG el emoji se dibuja como punto de color (las fuentes
  no traen emoji); en el BPMN va el emoji real, como en el ejemplo.
- **Ubicación**: dos bandas "Comentarios de revisión" con forma de carril, una **arriba** de los
  carriles (pasos en la fila 0 → la línea sube) y otra **abajo** (pasos en la fila 1 → la línea baja).
  Cada nota queda centrada sobre la columna de su paso (ancho 186 < paso entre columnas 196), así
  que ninguna nota se solapa con otra y la línea vertical no cruza flechas del flujo.
- **Salidas**: `-diagrama-flujo-comentarios.{pdf,png,svg}` y `-comentarios.bpmn` (con
  `textAnnotation` + `association` y su DI). El diagrama sin comentarios se conserva aparte.
- El BPMN con anotaciones es **BPMN 2.0 estándar**, no el formato nativo de Bizagi (ese camino fue
  descartado; ver `assets/PENDIENTE.md`).
