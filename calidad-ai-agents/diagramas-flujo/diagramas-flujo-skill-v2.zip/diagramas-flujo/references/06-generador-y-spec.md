# Generador y formato del spec JSON

`scripts/generar_diagrama.py spec.json [--salida DIR] [--formatos svg,png,pdf,bpmn,md] [--comentarios]`

El script falla con un mensaje claro si: un texto pasa de 100 caracteres, un paso no cabe en su caja
(> 6 líneas), un paso no pertenece a ninguna fase, hay decisiones sin `flujos`, una columna mezcla
fases, etc. Corregir el spec y volver a correr.

## Campos del spec

| Campo | Obligatorio | Descripción |
|---|---|---|
| `codigo` | sí | `"PR-016-RIS"` (nombra los archivos). |
| `version` | no | `"V1.0-2026"` (pie y BPMN). |
| `titulo` | sí | Nombre del procedimiento (título del lienzo y del pool). |
| `subtitulo` | no | `"PR-016-RIS · V1.0-2026 · Proceso ... · Subproceso ..."`. |
| `carriles` | sí | Lista de responsables, en orden de aparición. El índice es el `carril` de cada paso. |
| `fases` | no | `[{"nombre": "...", "pasos": ["1","2"]}]` — **solo si la fuente las define**. Cada paso (salvo inicio/fin) debe estar en una fase. |
| `pasos` | sí | Lista de pasos (abajo). El orden es el orden de la secuencia por defecto. |
| `flujos` | no* | `[{"de","a","etiqueta","ruta"}]`. *Obligatorio si hay decisiones. Sin `flujos` = secuencia por el orden de `pasos`. |
| `apilar` | no | `"auto"` (default): apila de a 2 pasos consecutivos del mismo carril y fase. `false` lo desactiva. |
| `inicio_fin` | no | `false` para no agregar Inicio/Fin automáticos (si se declaran explícitos). |
| `fecha` | no | `"29/09/2026"` (default: hoy). |
| `comentarios` | no | `true` (o la bandera `--comentarios`) dibuja las notas de revisión de los pasos 🟡/🔴. |

### Paso

| Campo | Descripción |
|---|---|
| `id` | Texto único. Para actividades y decisiones = número de la fuente (`"8"`, `"8.1"`). Eventos: `"ini"`, `"fin"`, `"f7"`. |
| `carril` | Índice en `carriles`. |
| `texto` | ≤ 100 caracteres. Decisión: pregunta cerrada con `?`. |
| `tipo` | `act` (default), `dec`, `ini`, `fin`. |
| `estado` | `verde` (default) · `amarillo` · `rojo`. |
| `nota` | Comentario de validación (obligatorio si amarillo/rojo). |
| `comentario` | Texto corto (≤ ~120 caracteres) de la nota de revisión dibujada con `--comentarios`; si falta se usa `nota`. |
| `col`, `fila` | **Modo manual**: columna global (0, 1, 2…) y fila dentro del carril (0 = principal, 1 = rama inferior). Si algún paso tiene `col`, todos deben tenerlo. |
| `num` | Solo si la etiqueta debe diferir del `id`. |
| `fase` | Solo para eventos: índice de fase donde ubicarlos (ini = 0 y fin = última por defecto). |

### Flujo

`ruta`: `std` (default: horizontal, o codo entre carriles, o vertical si están apilados) ·
`abajo` (sale por debajo del origen: rama "No" hacia una fila inferior; entra por arriba si el
destino está en la misma columna, o por la izquierda si no) · `retorno` (baja a un canal bajo el
carril, cruza hasta la columna del destino y entra por abajo de la caja destino).

## Cuándo automático y cuándo manual

- **Automático** (sin `col`): procedimiento lineal. Ver `assets/specs/pr-016-ris.json` (con fases).
- **Manual** (con `col`/`fila` + `flujos`): hay decisiones, ramas o retornos.
  Ver `assets/specs/pr-003-gri.json` (3 decisiones, retorno, 3 fines) y `pr-007-gri.json` (decisión
  con rama en fila inferior, 4 carriles).

Recetas de posicionamiento en manual:
- Rama "Sí" al frente (misma fila) y "No" abajo: destino del No en `fila: 1` **en la misma columna**
  del rombo con `ruta: "abajo"`; su Fin en la columna siguiente, `fila: 1`.
- Rama corta que reconecta más adelante (PR-007, paso 8): pasos de la rama en `fila: 1`, columnas
  propias, y el flujo "No" del rombo va recto por la fila 0 hasta el paso de reconexión.
- Retorno: `ruta: "retorno"` en el flujo del "No"; el carril del rombo gana un canal automáticamente.
- Una sola flecha por hueco entre columnas: no pongas dos pasos que reciban flechas del mismo hueco
  en columnas distintas sin necesidad; cada paso nuevo = columna nueva.

## Regresión

Tras cambiar el script, regenerar los tres specs de `assets/specs/` y revisar los PNG.
