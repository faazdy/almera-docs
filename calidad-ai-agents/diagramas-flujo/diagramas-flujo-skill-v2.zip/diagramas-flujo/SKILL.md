---
name: diagramas-flujo
description: >-
  Genera diagramas de flujo de procedimientos (estilo Bizagi Modeler) con CARRILES HORIZONTALES por
  responsable y, cuando la fuente las define, FASES como bandas verticales. Entrega PDF, PNG, SVG y
  BPMN 2.0 (bpmn.io / Camunda) a partir del cuadro de actividades del procedimiento (.doc/.docx).
  Úsala cuando el usuario pida "un diagrama de flujo", "diagramar un procedimiento", "flujograma",
  "el flujo de un proceso", "en BPMN", pase un procedimiento (PR-0xx-...) o el texto de sus
  actividades, o pida revisar/validar un diagrama existente. Reglas fijas: máximo 100 caracteres por
  actividad, numeración de la fuente, validación verde/amarillo/rojo, paleta consistente y
  variaciones (un diagrama general + N por variación). Siempre parte de la paleta de referencia.
---

# Diagramas de flujo de procedimientos

Produce el diagrama con el estilo visual de los procedimientos diagramados en Bizagi Modeler
(pool + carriles + eventos + actividades + rombos). El entregable es imagen/PDF/BPMN, **no** un
`.bpm` editable en Bizagi (Bizagi Modeler no importa BPMN 2.0 estándar; ver `assets/PENDIENTE.md`).

## Estándar por defecto (no hace falta que el usuario lo repita)

| Tema | Default |
|---|---|
| Orientación | Izquierda → derecha. |
| Responsables | **Carriles horizontales**, uno por responsable, dentro de un pool con el nombre del procedimiento. Un responsable = un solo carril aunque el flujo lo abandone y vuelva. |
| Fases | **Bandas verticales** con encabezado arriba y separadores punteados, **solo si la fuente las define** (filas de encabezado en el cuadro de actividades) o el usuario las pide. Nunca se infieren de indicios débiles. |
| Contenido por caja | Solo **responsable + número + actividad**. Se ignoran FRECUENCIA, EVIDENCIA O SOPORTE y ACTIVIDAD DE CONTROL salvo que el usuario los pida. |
| Numeración | La de la fuente (8.1, 8.2 si un paso se parte). Nunca una renumeración propia. |
| Texto | ≤ 100 caracteres, verbo en infinitivo + objeto; se recorta antes de partir. |
| Decisiones | Rombo con pregunta cerrada, **solo** si la fuente define la bifurcación. Decisión implícita → actividad plana + nota amarilla. |
| Validación | Punto verde/amarillo/rojo en la esquina de cada actividad/decisión + leyenda + tabla. |
| Salidas | **PDF + PNG + SVG** siempre; **BPMN 2.0** cuando lo piden (el script lo genera igual). |
| Comentarios de revisión | **Solo si el usuario los pide** (`--comentarios`): una nota gris por cada paso 🟡/🔴, ligada al paso con línea punteada, con el texto `Paso N — …` (ver `references/03`). |
| Herramienta | `scripts/generar_diagrama.py` (SVG → PDF/PNG con cairosvg). Mermaid queda como alternativa de reserva (ver `references/05`). |

## Flujo de trabajo

1. **Leer la fuente** (`references/07-lectura-de-fuentes.md`): convertir el `.doc` a `.docx`, extraer
   el cuadro (RESPONSABLE | No. | ACTIVIDAD), detectar fases explícitas, decisiones y retornos.
   Comparar con cargas anteriores (una carga idéntica no se rehace: se avisa).
2. **Estructura**: no preguntar lo que la fuente o el usuario ya definieron. Preguntar solo si hay
   ambigüedad real (p. ej. títulos en negrita dentro de actividades que podrían ser fases) — y aun
   así **decidir con lo que dice el cuadro, avisar y ofrecer la alternativa** al final.
3. **Redactar los pasos** con las reglas de `references/02-reglas-de-diagramacion.md` (≤ 100
   caracteres, sin nombres de formatos/códigos/normas dentro de la caja) y asignar a cada uno
   verde/amarillo/rojo + nota (`references/03-validacion-por-colores.md`).
4. **Escribir el spec JSON** (`references/06-generador-y-spec.md`, ejemplos en `assets/specs/`) y
   correr: `python3 scripts/generar_diagrama.py spec.json --salida /mnt/user-data/outputs`.
5. **Revisar el PNG por tramos** (recortes a resolución completa): textos que caben, flechas que
   tocan las cajas, etiquetas Sí/No legibles, nada cruzado. Ajustar y regenerar.
6. **Entregar** con `present_files` (PDF, PNG, SVG y, si se pidió, `.bpmn`) y un mensaje breve:
   estructura elegida, tabla de validación **solo de los pasos no verdes**, observaciones sobre la
   fuente (diagrama incrustado desactualizado, cosas del alcance que el cuadro no trae) y **una**
   pregunta de decisión pendiente.

## Reglas que no se negocian

- **≤ 100 caracteres** por actividad/acción (el script falla si se pasa). Recortar antes de partir.
- Paleta de `assets/paleta-bizagi.md` (el script ya la aplica). Nada de colores por defecto.
- Validación por colores en **todos** los diagramas, con leyenda visible:
  🟢 todo correcto · 🟡 parcialmente correcto, requiere revisar · 🔴 revisar obligatoriamente.
  El color va en el **punto**, nunca como relleno de la caja (el relleno indica el tipo).
- **No inventar ramas**: si la fuente no define el "No" de una pregunta, la pregunta no es un rombo.
- Con variaciones: diagrama general **+** uno por variación (`references/04-...`).
- Nunca entregar sin haber **visto** el render.
- Si se usa Mermaid (solo como reserva): sintaxis válida siempre (`<br/>`, flechas con etiqueta de
  tipo coincidente, sin `subgraph` con muchos cruces). Ver `references/02` → bugs confirmados.

## Índice de referencias

| Tema | Archivo |
|---|---|
| Flujo de trabajo detallado y cuándo preguntar | `references/01-flujo-de-trabajo.md` |
| Reglas de diagramación (100 caracteres, nomenclatura, layout, decisiones) | `references/02-reglas-de-diagramacion.md` |
| Validación por colores (verde / amarillo / rojo) | `references/03-validacion-por-colores.md` |
| Variaciones del procedimiento (general + N) | `references/04-variaciones-de-procedimiento.md` |
| Formatos de salida: PDF / PNG / SVG / BPMN | `references/05-formatos-de-salida.md` |
| Generador y formato del spec JSON | `references/06-generador-y-spec.md` |
| Lectura de la fuente (.doc/.docx), fases, duplicados | `references/07-lectura-de-fuentes.md` |
| Ejemplos de spec (PR-016 con fases, PR-003 con decisiones, PR-007 con carriles) | `assets/specs/` |

## Cómo se actualiza esta skill

Cuando cambie el estándar de Bizagi Modeler se actualiza `assets/paleta-bizagi.md` **y** las
constantes `P` de `scripts/generar_diagrama.py`. Los ejemplos de `assets/specs/` sirven de prueba
de regresión: deben seguir generándose sin error tras cualquier cambio del script.
