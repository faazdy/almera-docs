#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generar_diagrama.py — diagramas de flujo de procedimientos (estilo Bizagi) desde un spec JSON.

Estándar por defecto de la skill `diagramas-flujo`:
  * Pool con el nombre del procedimiento + CARRILES HORIZONTALES (un carril por responsable).
  * FASES como bandas VERTICALES (solo si la fuente las define explícitamente).
  * Numeración de actividades = numeración de la fuente (8.1, 8.2 si se parte un paso).
  * Actividades <= 100 caracteres. Decisiones = pregunta cerrada (rombo).
  * Punto de validación verde/amarillo/rojo en la esquina de cada actividad/decisión.
  * Salidas: SVG + PNG + PDF + BPMN 2.0 (con DI, para bpmn.io/Camunda) + tabla de validación .md

Uso:
    python3 generar_diagrama.py spec.json [--salida DIR] [--formatos svg,png,pdf,bpmn,md]

Dependencias: Pillow, cairosvg (pip install cairosvg --break-system-packages), fuentes DejaVu.
Formato del spec: ver references/06-generador-y-spec.md
"""
import argparse, html, json, os, re, sys, datetime
from xml.sax.saxutils import escape, quoteattr
from PIL import ImageFont

# ------------------------------------------------------------------ fuentes
def _find_font(names):
    for d in ("/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu", "/Library/Fonts", "C:/Windows/Fonts"):
        for n in names:
            p = os.path.join(d, n)
            if os.path.exists(p):
                return p
    raise SystemExit("No se encontró la fuente DejaVu Sans (Condensed). Instálala: apt-get install fonts-dejavu")
FONT_REG = _find_font(["DejaVuSansCondensed.ttf", "DejaVuSans.ttf"])
FONT_BLD = _find_font(["DejaVuSansCondensed-Bold.ttf", "DejaVuSans-Bold.ttf"])
FAMILY = "DejaVu Sans Condensed"
_fc = {}
def _font(size, bold):
    k = (size, bold)
    if k not in _fc: _fc[k] = ImageFont.truetype(FONT_BLD if bold else FONT_REG, size)
    return _fc[k]
def measure(t, s, b=False): return _font(s, b).getlength(t)
def wrap(txt, size, maxw, bold=False):
    lines, cur = [], ""
    for w in txt.split():
        t = (cur + " " + w).strip()
        if measure(t, size, bold) <= maxw: cur = t
        else:
            if cur: lines.append(cur)
            cur = w
    if cur: lines.append(cur)
    return lines

# ------------------------------------------------------------------ paleta (assets/paleta-bizagi.md)
P = dict(ev_ini=("#E8FFA6", "#A0B16A", "#4B5A2E"), ev_fin=("#E9B2AC", "#9E4650", "#5A2226"),
         act=("#EAF0FC", "#6F90AA", "#1A2E4A"), dec=("#FFFFCE", "#AEB578", "#5B5A2E"),
         lane_hdr=("#F5F5F5", "#666666", "#333333"), fase=("#FAFAFA", "#999999", "#333333"),
         flow="#4D4D4D", lane_line="#A6A6A6",
         verde="#2E7D32", amarillo="#F2C037", rojo="#C0392B")
EMOJI = {"verde": "🟢", "amarillo": "🟡", "rojo": "🔴"}

# ------------------------------------------------------------------ geometría
POOL_W, LANE_W = 40, 56
BW, BH, R, DH = 148, 92, 22, 34
GAP = 48; PITCH = BW + GAP; PADP = 24
HDR = 52; TOP = 96
ROW0, ROW_STEP = 62, 116
LANE_MIN = 150
CHANNEL_EXTRA = 60
MAX_CHARS = 100
# Comentarios de revisión (notas grises ligadas al paso por una línea punteada, como en el ejemplo
# recibido: texto "🟡 Paso N — ..." en nota gris #D5D5D5 + asociación). Solo pasos amarillo/rojo.
NOTE_W, NOTE_PAD, NOTE_FS = 186, 14, 10.5
NOTE_FILL, NOTE_STROKE = "#D5D5D5", "#B8B8B8"
EMOJI_PUNTO = {"amarillo": "🟡", "rojo": "🔴"}

def die(msg): raise SystemExit("ERROR: " + msg)

class Nodo:
    def __init__(s, d, idx):
        s.id = str(d["id"]); s.kind = d.get("tipo", "act")
        if s.kind not in ("act", "dec", "ini", "fin"): die(f"paso {s.id}: tipo inválido '{s.kind}'")
        s.lane = d.get("carril"); s.text = d.get("texto", {"ini": "Inicio", "fin": "Fin"}.get(s.kind, ""))
        s.num = str(d.get("num", s.id if s.kind in ("act", "dec") else ""))
        s.val = d.get("estado", "verde" if s.kind in ("act", "dec") else None)
        if s.val not in (None, "verde", "amarillo", "rojo"): die(f"paso {s.id}: estado inválido '{s.val}'")
        s.note = d.get("nota", ""); s.col = d.get("col"); s.row = d.get("fila"); s.comment = d.get("comentario", "")
        s.fase = d.get("fase"); s.order = idx
    @property
    def is_event(s): return s.kind in ("ini", "fin")

def cargar(path):
    spec = json.load(open(path, encoding="utf-8"))
    for k in ("codigo", "titulo", "carriles", "pasos"):
        if k not in spec: die(f"falta '{k}' en el spec")
    return spec

def construir(spec):
    lanes = spec["carriles"]
    nodes = [Nodo(d, i) for i, d in enumerate(spec["pasos"])]
    ids = [n.id for n in nodes]
    if len(ids) != len(set(ids)): die("ids de paso repetidos")
    # inicio / fin automáticos
    if spec.get("inicio_fin", True):
        if not any(n.kind == "ini" for n in nodes):
            first = next(n for n in nodes if not n.is_event)
            nodes.insert(0, Nodo({"id": "ini", "tipo": "ini", "carril": first.lane}, -1))
        if not any(n.kind == "fin" for n in nodes):
            last = [n for n in nodes if not n.is_event][-1]
            nodes.append(Nodo({"id": "fin", "tipo": "fin", "carril": last.lane}, 10**6))
    for n in nodes:
        if n.lane is None or not (0 <= n.lane < len(lanes)): die(f"paso {n.id}: 'carril' fuera de rango")
    # límite de 100 caracteres
    bad = [(n.id, len(n.text)) for n in nodes if n.kind in ("act", "dec") and len(n.text) > MAX_CHARS]
    if bad:
        die("Texto > %d caracteres (recorta o parte el paso, ver references/02): %s" % (MAX_CHARS, bad))
    byid = {n.id: n for n in nodes}
    # fases
    fases = spec.get("fases")
    phase_of = {}
    if fases:
        for pi, f in enumerate(fases):
            for pid in f["pasos"]:
                if str(pid) not in byid: die(f"fase '{f['nombre']}': el paso {pid} no existe")
                phase_of[str(pid)] = pi
        for n in nodes:
            if n.id in phase_of: continue
            if n.fase is not None: phase_of[n.id] = n.fase
            elif n.kind == "ini": phase_of[n.id] = 0
            elif n.kind == "fin": phase_of[n.id] = len(fases) - 1
            else: die(f"el paso {n.id} no pertenece a ninguna fase")
    # flujos
    if spec.get("flujos"):
        flows = [dict(de=str(f["de"]), a=str(f["a"]), etiqueta=f.get("etiqueta", ""), ruta=f.get("ruta", "std")) for f in spec["flujos"]]
        for f in flows:
            if f["de"] not in byid or f["a"] not in byid: die(f"flujo con paso inexistente: {f}")
    else:
        if any(n.kind == "dec" for n in nodes): die("hay decisiones: define 'flujos' explícitos (con etiquetas Sí/No)")
        flows = [dict(de=a.id, a=b.id, etiqueta="", ruta="std") for a, b in zip(nodes, nodes[1:])]
    return lanes, nodes, byid, fases, phase_of, flows

def asignar_columnas(spec, nodes, phase_of):
    manual = any(n.col is not None for n in nodes)
    if manual:
        for n in nodes:
            if n.col is None: die(f"modo manual: el paso {n.id} no tiene 'col'")
            if n.row is None: n.row = 0
    else:
        apilar = spec.get("apilar", "auto")
        if apilar == "auto": apilar = True
        cols = []
        for n in nodes:
            ph = phase_of.get(n.id)
            if (apilar and cols and n.kind == "act" and cols[-1]["ph"] == ph and len(cols[-1]["ids"]) == 1
                    and cols[-1]["ids"][0].kind == "act" and cols[-1]["ids"][0].lane == n.lane):
                cols[-1]["ids"].append(n)
            else:
                cols.append(dict(ph=ph, ids=[n]))
        for ci, c in enumerate(cols):
            for r, n in enumerate(c["ids"]): n.col, n.row = ci, r
    return manual

def geometria(spec, lanes, nodes, fases, phase_of, flows, byid):
    G = {}
    colset = sorted({n.col for n in nodes})
    X0 = 10 + POOL_W + LANE_W
    cx_of = {}; bands = []
    if fases:
        col_ph = {}
        for n in nodes:
            ph = phase_of[n.id]
            if col_ph.setdefault(n.col, ph) != ph: die(f"la columna {n.col} mezcla pasos de fases distintas (paso {n.id})")
        x = X0; prev_max = -1
        for pi, f in enumerate(fases):
            mine = sorted(c for c, p in col_ph.items() if p == pi)
            if not mine: die(f"la fase '{f['nombre']}' no tiene pasos")
            if mine[0] <= prev_max: die("las columnas de las fases se intercalan; ordénalas por fase")
            prev_max = mine[-1]
            w = 2 * PADP + BW + (len(mine) - 1) * PITCH
            bands.append((x, w))
            for i, c in enumerate(mine): cx_of[c] = x + PADP + BW / 2 + i * PITCH
            x += w
        content_r = x
    else:
        for i, c in enumerate(colset): cx_of[c] = X0 + PADP + BW / 2 + i * PITCH
        content_r = X0 + 2 * PADP + BW + (len(colset) - 1) * PITCH
    W = int(content_r + 10 + (10 if fases else 20))
    # alturas de carril
    rows = [1] * len(lanes)
    for n in nodes: rows[n.lane] = max(rows[n.lane], n.row + 1)
    chan = [False] * len(lanes)
    for f in flows:
        if f["ruta"] == "retorno": chan[byid[f["de"]].lane] = True
    # holgura superior: la pregunta de una decisión en la fila 0 se dibuja ENCIMA del rombo
    top_pad = [0] * len(lanes)
    for n in nodes:
        if n.kind == "dec" and n.row == 0:
            nl = len(wrap(f"{n.num}. {n.text}", 11.5, 190))
            top_pad[n.lane] = max(top_pad[n.lane], int(nl * 13.5 + 6 + 10 - (ROW0 - DH)) + 1)
    lane_h = []
    for i, name in enumerate(lanes):
        h = 124 + top_pad[i] + ROW_STEP * (rows[i] - 1) + (CHANNEL_EXTRA if chan[i] else 0)
        h = max(h, LANE_MIN)
        while len(wrap(name, 12, h - 20, True)) > 3: h += 20
        lane_h.append(h)
    hdr = HDR if fases else 0
    notes_top = TOP + hdr
    # ---- comentarios de revisión: fila 0 -> banda superior (la línea sube); fila 1 -> banda inferior (baja)
    notes = []
    if spec.get("comentarios"):
        for n in nodes:
            if n.kind not in ("act", "dec") or n.val not in ("amarillo", "rojo"): continue
            txt = (n.comment or n.note or "").strip()
            if not txt: continue
            side = "top" if n.row == 0 else "bottom"
            lines = wrap(f"Paso {n.num} — {txt}", NOTE_FS, NOTE_W - 34)
            nh = max(46, int(len(lines) * (NOTE_FS + 2.5) + 18))
            notes.append(dict(id=n.id, side=side, lines=lines, h=nh, x=cx_of[n.col] - NOTE_W / 2, cx=cx_of[n.col], val=n.val, text=txt))
    BAND_MIN = 112      # alto mínimo para que quepa el rótulo vertical "Comentarios de revisión" (2 líneas)
    top_h = max(BAND_MIN, max([m["h"] for m in notes if m["side"] == "top"], default=0) + 2 * NOTE_PAD + 22) if any(m["side"] == "top" for m in notes) else 0
    bot_h = max(BAND_MIN, max([m["h"] for m in notes if m["side"] == "bottom"], default=0) + 2 * NOTE_PAD + 22) if any(m["side"] == "bottom" for m in notes) else 0
    lanes_top = notes_top + top_h
    lane_top = []; y = lanes_top
    for h in lane_h: lane_top.append(y); y += h
    LB = y
    END = LB + bot_h
    H = int(END + 100)
    pos = {}
    for n in nodes: pos[n.id] = (cx_of[n.col], lane_top[n.lane] + top_pad[n.lane] + ROW0 + ROW_STEP * n.row)
    for m in notes:
        m["y"] = (notes_top + NOTE_PAD) if m["side"] == "top" else (LB + NOTE_PAD)
    G.update(dict(notes=notes, notes_top=notes_top, top_h=top_h, bot_h=bot_h, END=END, W=W, H=H, LB=LB, lanes_top=lanes_top, lane_top=lane_top, lane_h=lane_h, hdr=hdr, bands=bands,
                  pos=pos, rows=rows, top_pad=top_pad, cx_of=cx_of, content_r=content_r))
    return G

def dims(n):
    if n.is_event: return R, R
    if n.kind == "dec": return DH, DH
    return BW / 2, BH / 2

def rutas(nodes, byid, flows, G):
    pos = G["pos"]; out = []
    for f in flows:
        a, b = byid[f["de"]], byid[f["a"]]
        (xa, ya), (xb, yb) = pos[a.id], pos[b.id]
        wa, ha = dims(a); wb, hb = dims(b)
        r = f["ruta"]; lab = f["etiqueta"]; lp = None
        if r == "std":
            if a.col == b.col and a.id != b.id:      # apilados en la misma columna
                if yb > ya: wp = [(xa, ya + ha), (xb, yb - hb)]
                else: wp = [(xa, ya - ha), (xb, yb + hb)]
                lp = (xa + 14, ya + ha + 16)
            else:
                x1, x2 = xa + wa, xb - wb
                if abs(ya - yb) < .1: wp = [(x1, ya), (x2, yb)]
                else:
                    mx = x1 + 0.3 * (x2 - x1); wp = [(x1, ya), (mx, ya), (mx, yb), (x2, yb)]
                lp = (x1 + 16, ya - 8)
        elif r == "abajo":                            # sale por abajo del origen
            if a.col == b.col: wp = [(xa, ya + ha), (xb, yb - hb)]
            else: wp = [(xa, ya + ha), (xa, yb), (xb - wb, yb)]
            lp = (xa + 14, ya + ha + 16)
        elif r == "retorno":                          # baja al canal del carril, vuelve y entra por abajo del destino
            lane = a.lane
            chan_y = G["lane_top"][lane] + G["top_pad"][lane] + ROW0 + ROW_STEP * (G["rows"][lane] - 1) + BH / 2 + 30
            wp = [(xa, ya + ha), (xa, chan_y), (xb, chan_y), (xb, yb + hb)]
            lp = (xa + 14, ya + ha + 16)
        else: die(f"ruta desconocida '{r}' (usa std | abajo | retorno)")
        out.append((a.id, b.id, lab, wp, lp))
    return out

# ------------------------------------------------------------------ SVG
def render_svg(spec, lanes, nodes, byid, fases, phase_of, flows, G, R_):
    W, H, LB, lanes_top, lane_top, lane_h, hdr, bands, pos = (G[k] for k in ("W", "H", "LB", "lanes_top", "lane_top", "lane_h", "hdr", "bands", "pos"))
    notes, notes_top, top_h, bot_h, END = G["notes"], G["notes_top"], G["top_h"], G["bot_h"], G["END"]
    titulo, sub = spec["titulo"], spec.get("subtitulo", "")
    o = []; a = o.append
    a(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="{FAMILY}, DejaVu Sans, Arial, sans-serif">')
    a(f'<rect width="{W}" height="{H}" fill="#FFFFFF"/>')
    a(f'<defs><marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{P["flow"]}"/></marker></defs>')
    a(f'<text x="24" y="34" font-size="20" font-weight="bold" fill="#111">{html.escape(titulo)}</text>')
    if sub: a(f'<text x="24" y="58" font-size="12" fill="#555">{html.escape(sub)}</text>')
    ph_total = END - TOP
    a(f'<rect x="10" y="{TOP}" width="{W-20}" height="{ph_total}" fill="#FFFFFF" stroke="{P["lane_line"]}" stroke-width="1.5"/>')
    if fases:
        for pi, f in enumerate(fases):
            bx, bw = bands[pi]
            if pi % 2 == 1: a(f'<rect x="{bx}" y="{notes_top}" width="{bw}" height="{END-notes_top}" fill="#FAFAFA"/>')
            a(f'<rect x="{bx}" y="{TOP}" width="{bw}" height="{hdr}" fill="{P["fase"][0]}" stroke="{P["fase"][1]}" stroke-width="1.2"/>')
            ls = wrap(f["nombre"].upper(), 12, bw - 20, True); lh = 15; y0 = TOP + hdr / 2 - (len(ls) - 1) * lh / 2 + 4
            for j, ln in enumerate(ls):
                a(f'<text x="{bx+bw/2}" y="{y0+j*lh}" text-anchor="middle" font-size="12" font-weight="bold" fill="{P["fase"][2]}">{html.escape(ln)}</text>')
            if pi > 0: a(f'<line x1="{bx}" y1="{notes_top}" x2="{bx}" y2="{END}" stroke="{P["fase"][1]}" stroke-width="1.4" stroke-dasharray="7,5"/>')
    a(f'<rect x="10" y="{TOP}" width="{POOL_W}" height="{ph_total}" fill="#FFFFFF" stroke="{P["lane_hdr"][1]}" stroke-width="1.5"/>')
    pl = wrap(titulo, 12, ph_total - 24, True)
    for j, ln in enumerate(pl):
        xx = 10 + POOL_W / 2 + 4 - (len(pl) - 1) * 7.5 + j * 15
        a(f'<text transform="translate({xx},{TOP+ph_total/2}) rotate(-90)" text-anchor="middle" font-size="12" font-weight="bold" fill="#222">{html.escape(ln)}</text>')
    if hdr: a(f'<rect x="{10+POOL_W}" y="{TOP}" width="{LANE_W}" height="{hdr}" fill="#FFFFFF" stroke="{P["lane_hdr"][1]}" stroke-width="1.2"/>')
    for i, name in enumerate(lanes):
        t, h = lane_top[i], lane_h[i]
        a(f'<rect x="{10+POOL_W}" y="{t}" width="{LANE_W}" height="{h}" fill="{P["lane_hdr"][0]}" stroke="{P["lane_hdr"][1]}" stroke-width="1.5"/>')
        a(f'<line x1="{10+POOL_W+LANE_W}" y1="{t}" x2="{W-10}" y2="{t}" stroke="{P["lane_line"]}" stroke-width="1.5"/>')
        ls = wrap(name, 12, h - 20, True); lh = 15; ccx = 10 + POOL_W + LANE_W / 2 + 4
        for j, ln in enumerate(ls):
            a(f'<text transform="translate({ccx-(len(ls)-1)*lh/2+j*lh},{t+h/2}) rotate(-90)" text-anchor="middle" font-size="12" font-weight="bold" fill="{P["lane_hdr"][2]}">{html.escape(ln)}</text>')
    for (y0, h0, side) in ((notes_top, top_h, "top"), (LB, bot_h, "bottom")):
        if not h0: continue
        a(f'<rect x="{10+POOL_W}" y="{y0}" width="{LANE_W}" height="{h0}" fill="#EFEFEF" stroke="{P["lane_hdr"][1]}" stroke-width="1.5"/>')
        a(f'<line x1="{10+POOL_W+LANE_W}" y1="{y0}" x2="{W-10}" y2="{y0}" stroke="{P["lane_line"]}" stroke-width="1.5"/>')
        ls_ = wrap("Comentarios de revisión", 11.5, h0 - 16, True)
        for j_, ln_ in enumerate(ls_):
            a(f'<text transform="translate({10+POOL_W+LANE_W/2+4-(len(ls_)-1)*7.5+j_*15},{y0+h0/2}) rotate(-90)" text-anchor="middle" font-size="11.5" font-weight="bold" fill="{P["lane_hdr"][2]}">{html.escape(ln_)}</text>')
    if notes: a(f'<line x1="{10+POOL_W+LANE_W}" y1="{LB}" x2="{W-10}" y2="{LB}" stroke="{P["lane_line"]}" stroke-width="1.5"/>')
    for m in notes:
        n = byid[m["id"]]; x, y_ = pos[n.id]; wa, ha = dims(n)
        if m["side"] == "top":
            y_node = y_ - ha if n.kind == "act" else y_ - DH - 6 - len(wrap(f"{n.num}. {n.text}", 11.5, 190)) * 13.5 - 4
            a(f'<line x1="{m["cx"]}" y1="{y_node}" x2="{m["cx"]}" y2="{m["y"]+m["h"]}" stroke="#6E6E6E" stroke-width="1.3" stroke-dasharray="2,3"/>')
        else:
            a(f'<line x1="{m["cx"]}" y1="{y_+ha}" x2="{m["cx"]}" y2="{m["y"]}" stroke="#6E6E6E" stroke-width="1.3" stroke-dasharray="2,3"/>')
    for m in notes:
        a(f'<rect x="{m["x"]}" y="{m["y"]}" width="{NOTE_W}" height="{m["h"]}" rx="3" fill="{NOTE_FILL}" stroke="{NOTE_STROKE}" stroke-width="1"/>')
        a(f'<circle cx="{m["x"]+13}" cy="{m["y"]+14}" r="5.5" fill="{P[m["val"]]}" stroke="#FFFFFF" stroke-width="1.5"/>')
        for j, ln in enumerate(m["lines"]):
            a(f'<text x="{m["x"]+24}" y="{m["y"]+17+j*(NOTE_FS+2.5):.1f}" font-size="{NOTE_FS}" fill="#1A1A1A">{html.escape(ln)}</text>')
    for s, t, lab, wp, lp in R_:
        d = "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in wp)
        a(f'<path d="{d}" fill="none" stroke="{P["flow"]}" stroke-width="1.6" stroke-linejoin="miter" marker-end="url(#arr)"/>')
        if lab:
            w = measure(lab, 12, True) + 8
            a(f'<rect x="{lp[0]-w/2}" y="{lp[1]-11}" width="{w}" height="16" fill="#FFFFFF"/>')
            a(f'<text x="{lp[0]}" y="{lp[1]+1}" text-anchor="middle" font-size="12" font-weight="bold" fill="#333">{html.escape(lab)}</text>')
    def dot(x, y, key): a(f'<circle cx="{x}" cy="{y}" r="7.5" fill="{P[key]}" stroke="#FFFFFF" stroke-width="2"/>')
    for n in nodes:
        x, y = pos[n.id]
        if n.kind == "ini":
            f, s, c = P["ev_ini"]
            a(f'<circle cx="{x}" cy="{y}" r="{R}" fill="{f}" stroke="{s}" stroke-width="2.5"/><text x="{x}" y="{y+4}" text-anchor="middle" font-size="11" font-weight="bold" fill="{c}">Inicio</text>')
        elif n.kind == "fin":
            f, s, c = P["ev_fin"]
            a(f'<circle cx="{x}" cy="{y}" r="{R}" fill="{f}" stroke="{s}" stroke-width="3.5"/><text x="{x}" y="{y+4}" text-anchor="middle" font-size="11" font-weight="bold" fill="{c}">Fin</text>')
        elif n.kind == "act":
            f, s, c = P["act"]
            a(f'<rect x="{x-BW/2}" y="{y-BH/2}" width="{BW}" height="{BH}" rx="9" fill="{f}" stroke="{s}" stroke-width="1.6"/>')
            ls = wrap(f"{n.num}. {n.text}", 11.2, BW - 16); lh = 13.2; y0 = y - (len(ls) - 1) * lh / 2 + 4
            if len(ls) > 6: die(f"paso {n.id}: el texto no cabe en la caja (>6 líneas); acórtalo")
            for j, ln in enumerate(ls):
                a(f'<text x="{x}" y="{y0+j*lh:.1f}" text-anchor="middle" font-size="11.2" fill="{c}">{html.escape(ln)}</text>')
            dot(x + BW / 2 - 3, y - BH / 2 + 3, n.val)
        else:
            f, s, c = P["dec"]
            a(f'<polygon points="{x},{y-DH} {x+DH},{y} {x},{y+DH} {x-DH},{y}" fill="{f}" stroke="{s}" stroke-width="1.8"/>')
            ls = wrap(f"{n.num}. {n.text}", 11.5, 190); lh = 13.5; yb = y - DH - 6 - (len(ls) - 1) * lh
            for j, ln in enumerate(ls):
                a(f'<text x="{x}" y="{yb+j*lh:.1f}" text-anchor="middle" font-size="11.5" font-weight="bold" fill="{c}">{html.escape(ln)}</text>')
            dot(x + DH - 6, y - DH + 12, n.val)
    ly = END + 32
    a(f'<text x="24" y="{ly}" font-size="12" font-weight="bold" fill="#222">Validación</text>')
    xx = 110
    for key, label in [("verde", "Todo correcto"), ("amarillo", "Parcialmente correcto, requiere revisar"), ("rojo", "Revisar obligatoriamente")]:
        a(f'<circle cx="{xx}" cy="{ly-4}" r="7.5" fill="{P[key]}" stroke="#FFFFFF" stroke-width="2"/><text x="{xx+14}" y="{ly}" font-size="12" fill="#333">{label}</text>')
        xx += 14 + measure(label, 12) + 34
    ver = spec.get("version", "")
    foot = (f"El color del punto indica el estado de validación de cada paso, no el tipo de elemento. "
            f"Numeración según el cuadro de actividades de {spec['codigo']}{(' ' + ver) if ver else ''}. Generado el {spec.get('fecha', datetime.date.today().strftime('%d/%m/%Y'))}.")
    a(f'<text x="24" y="{ly+26}" font-size="11" fill="#777">{html.escape(foot)}</text>')
    a('</svg>')
    return "\n".join(o)

# ------------------------------------------------------------------ BPMN 2.0 (con DI)
def safe(s): return re.sub(r"[^A-Za-z0-9_]", "_", s)
def render_bpmn(spec, lanes, nodes, byid, fases, phase_of, flows, G, R_):
    W, LB, lanes_top, lane_top, lane_h, bands, pos = (G[k] for k in ("W", "LB", "lanes_top", "lane_top", "lane_h", "bands", "pos"))
    notes, END = G["notes"], G["END"]
    cod = safe(spec["codigo"])
    def eid(n):
        return {"ini": "StartEvent_" + safe(n.id), "fin": "EndEvent_" + safe(n.id), "dec": "Gateway_" + safe(n.id)}.get(n.kind, "Task_" + safe(n.num or n.id))
    fl_ids = []; seen = {}
    for s, t, lab, wp, lp in R_:
        base = f"Flow_{eid(byid[s])}__{eid(byid[t])}"
        seen[base] = seen.get(base, 0) + 1
        fl_ids.append(base if seen[base] == 1 else f"{base}_{seen[base]}")
    inc, outg = {}, {}
    for (s, t, *_), fid in zip(R_, fl_ids): outg.setdefault(s, []).append(fid); inc.setdefault(t, []).append(fid)
    o = []; a = o.append
    a('<?xml version="1.0" encoding="UTF-8"?>')
    a(f'<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:bioc="http://bpmn.io/schema/bpmn/biocolor/1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="Definitions_{cod}" targetNamespace="http://capitalsalud.local/bpmn/{cod.lower()}" exporter="skill diagramas-flujo (Claude)" exporterVersion="2.0">')
    if fases:
        a('  <bpmn:category id="Category_Fases">')
        for i, f in enumerate(fases): a(f'    <bpmn:categoryValue id="CategoryValue_Fase{i+1}" value={quoteattr(f["nombre"].upper())} />')
        a('  </bpmn:category>')
    a('  <bpmn:collaboration id="Collaboration_1">')
    a(f'    <bpmn:participant id="Participant_1" name={quoteattr(spec["titulo"])} processRef="Process_{cod}" />')
    if fases:
        for i in range(len(fases)): a(f'    <bpmn:group id="Group_Fase{i+1}" categoryValueRef="CategoryValue_Fase{i+1}" />')
    a('  </bpmn:collaboration>')
    a(f'  <bpmn:process id="Process_{cod}" name={quoteattr(spec["titulo"])} isExecutable="false">')
    a(f'    <bpmn:documentation>{escape(spec["codigo"])} {escape(spec.get("version", ""))} — {escape(spec.get("subtitulo", ""))}. Numeración igual al cuadro de actividades de la fuente. Generado por la skill diagramas-flujo.</bpmn:documentation>')
    a('    <bpmn:laneSet id="LaneSet_1">')
    for i, name in enumerate(lanes):
        a(f'      <bpmn:lane id="Lane_{i+1}" name={quoteattr(name)}>')
        for n in nodes:
            if n.lane == i: a(f'        <bpmn:flowNodeRef>{eid(n)}</bpmn:flowNodeRef>')
        a('      </bpmn:lane>')
    a('    </bpmn:laneSet>')
    for n in nodes:
        tag = {"ini": "startEvent", "fin": "endEvent", "act": "task", "dec": "exclusiveGateway"}[n.kind]
        label = n.text if n.is_event else f"{n.num}. {n.text}"
        extra = ""
        if n.kind == "dec":
            nof = [fid for (s, t, lab, *_), fid in zip(R_, fl_ids) if s == n.id and lab.strip().lower() == "no"]
            if nof: extra = f' default="{nof[0]}"'
        a(f'    <bpmn:{tag} id="{eid(n)}" name={quoteattr(label)}{extra}>')
        doc = ""
        if fases and n.id in phase_of: doc += f"Fase: {fases[phase_of[n.id]]['nombre']}. "
        if n.val in ("amarillo", "rojo") and n.note: doc += f"{n.val.capitalize()}: {n.note}"
        elif n.note: doc += n.note
        if doc.strip(): a(f'      <bpmn:documentation>{escape(doc.strip())}</bpmn:documentation>')
        for f in inc.get(n.id, []): a(f'      <bpmn:incoming>{f}</bpmn:incoming>')
        for f in outg.get(n.id, []): a(f'      <bpmn:outgoing>{f}</bpmn:outgoing>')
        a(f'    </bpmn:{tag}>')
    for (s, t, lab, wp, lp), fid in zip(R_, fl_ids):
        nm = f" name={quoteattr(lab)}" if lab else ""
        a(f'    <bpmn:sequenceFlow id="{fid}"{nm} sourceRef="{eid(byid[s])}" targetRef="{eid(byid[t])}" />')
    for m in notes:
        n = byid[m["id"]]
        a(f'    <bpmn:textAnnotation id="Annotation_{safe(n.id)}"><bpmn:text>{escape(EMOJI_PUNTO[m["val"]] + " Paso " + n.num + " — " + m["text"])}</bpmn:text></bpmn:textAnnotation>')
        a(f'    <bpmn:association id="Association_{safe(n.id)}" sourceRef="{eid(n)}" targetRef="Annotation_{safe(n.id)}" />')
    a('  </bpmn:process>')
    a('  <bpmndi:BPMNDiagram id="BPMNDiagram_1"><bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Collaboration_1">')
    a(f'    <bpmndi:BPMNShape id="Participant_1_di" bpmnElement="Participant_1" isHorizontal="true"><dc:Bounds x="10" y="{lanes_top}" width="{W-20}" height="{LB-lanes_top}" /></bpmndi:BPMNShape>')
    for i in range(len(lanes)):
        a(f'    <bpmndi:BPMNShape id="Lane_{i+1}_di" bpmnElement="Lane_{i+1}" isHorizontal="true"><dc:Bounds x="40" y="{lane_top[i]}" width="{W-50}" height="{lane_h[i]}" /></bpmndi:BPMNShape>')
    COL = {"ini": ("#E8FFA6", "#A0B16A"), "fin": ("#E9B2AC", "#9E4650"), "act": ("#EAF0FC", "#6F90AA"), "dec": ("#FFFFCE", "#AEB578")}
    for n in nodes:
        x, y = pos[n.id]; fl, st = COL[n.kind]; cc = f'bioc:stroke="{st}" bioc:fill="{fl}"'
        if n.kind == "act":
            a(f'    <bpmndi:BPMNShape id="{eid(n)}_di" bpmnElement="{eid(n)}" {cc}><dc:Bounds x="{x-BW/2:.0f}" y="{y-BH/2:.0f}" width="{BW}" height="{BH}" /></bpmndi:BPMNShape>')
        elif n.kind == "dec":
            a(f'    <bpmndi:BPMNShape id="{eid(n)}_di" bpmnElement="{eid(n)}" isMarkerVisible="true" {cc}><dc:Bounds x="{x-DH:.0f}" y="{y-DH:.0f}" width="{2*DH}" height="{2*DH}" /><bpmndi:BPMNLabel><dc:Bounds x="{x-100:.0f}" y="{y-DH-48:.0f}" width="200" height="44" /></bpmndi:BPMNLabel></bpmndi:BPMNShape>')
        else:
            a(f'    <bpmndi:BPMNShape id="{eid(n)}_di" bpmnElement="{eid(n)}" {cc}><dc:Bounds x="{x-R:.0f}" y="{y-R:.0f}" width="{2*R}" height="{2*R}" /><bpmndi:BPMNLabel><dc:Bounds x="{x-R:.0f}" y="{y+R+2:.0f}" width="{2*R}" height="14" /></bpmndi:BPMNLabel></bpmndi:BPMNShape>')
    for (s, t, lab, wp, lp), fid in zip(R_, fl_ids):
        a(f'    <bpmndi:BPMNEdge id="{fid}_di" bpmnElement="{fid}">')
        for (px, py) in wp: a(f'      <di:waypoint x="{px:.0f}" y="{py:.0f}" />')
        if lab and lp: a(f'      <bpmndi:BPMNLabel><dc:Bounds x="{lp[0]-8:.0f}" y="{lp[1]-12:.0f}" width="16" height="14" /></bpmndi:BPMNLabel>')
        a('    </bpmndi:BPMNEdge>')
    if fases:
        for i, f in enumerate(fases):
            bx, bw = bands[i]
            a(f'    <bpmndi:BPMNShape id="Group_Fase{i+1}_di" bpmnElement="Group_Fase{i+1}"><dc:Bounds x="{bx:.0f}" y="{TOP}" width="{bw:.0f}" height="{END-TOP}" /><bpmndi:BPMNLabel><dc:Bounds x="{bx+bw/2-100:.0f}" y="{TOP+14}" width="200" height="28" /></bpmndi:BPMNLabel></bpmndi:BPMNShape>')
    for m in notes:
        n = byid[m["id"]]; x, y_ = pos[n.id]; wa, ha = dims(n)
        a(f'    <bpmndi:BPMNShape id="Annotation_{safe(n.id)}_di" bpmnElement="Annotation_{safe(n.id)}"><dc:Bounds x="{m["x"]:.0f}" y="{m["y"]}" width="{NOTE_W}" height="{m["h"]}" /></bpmndi:BPMNShape>')
        y_node = (y_ - ha) if m["side"] == "top" else (y_ + ha)
        y_note = (m["y"] + m["h"]) if m["side"] == "top" else m["y"]
        a(f'    <bpmndi:BPMNEdge id="Association_{safe(n.id)}_di" bpmnElement="Association_{safe(n.id)}"><di:waypoint x="{m["cx"]:.0f}" y="{y_node:.0f}" /><di:waypoint x="{m["cx"]:.0f}" y="{y_note:.0f}" /></bpmndi:BPMNEdge>')
    a('  </bpmndi:BPMNPlane></bpmndi:BPMNDiagram>')
    a('</bpmn:definitions>')
    return "\n".join(o) + "\n"


# ------------------------------------------------------------------ tabla de validación (.md)
def render_md(spec, lanes, nodes):
    L = [f"# Validación — {spec['codigo']} {spec.get('version', '')}", "",
         "| # | Responsable | Paso | Color | Comentario |", "|---|---|---|---|---|"]
    for n in nodes:
        if n.is_event: continue
        com = n.note if n.val in ("amarillo", "rojo") else "—"
        if n.val in ("amarillo", "rojo") and not n.note: com = "(falta comentario)"
        L.append(f"| {n.num} | {lanes[n.lane]} | {n.text} | {EMOJI[n.val]} | {com} |")
    L += ["", "🟢 Todo correcto · 🟡 Parcialmente correcto, requiere revisar · 🔴 Revisar obligatoriamente", ""]
    return "\n".join(L)

# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("spec"); ap.add_argument("--salida", default=".")
    ap.add_argument("--formatos", default="svg,png,pdf,bpmn,md")
    ap.add_argument("--comentarios", action="store_true", help="agrega notas de revisión (pasos amarillo/rojo) como en assets/ejemplos-reales")
    args = ap.parse_args()
    fm = {x.strip() for x in args.formatos.split(",")}
    spec = cargar(args.spec)
    if args.comentarios: spec["comentarios"] = True
    lanes, nodes, byid, fases, phase_of, flows = construir(spec)
    asignar_columnas(spec, nodes, phase_of)
    G = geometria(spec, lanes, nodes, fases, phase_of, flows, byid)
    R_ = rutas(nodes, byid, flows, G)
    os.makedirs(args.salida, exist_ok=True)
    base = os.path.join(args.salida, spec["codigo"])
    sfx = "-comentarios" if spec.get("comentarios") else ""
    svg = render_svg(spec, lanes, nodes, byid, fases, phase_of, flows, G, R_)
    out = []
    if "svg" in fm: open(base + "-diagrama-flujo" + sfx + ".svg", "w", encoding="utf-8").write(svg); out.append("svg")
    if fm & {"png", "pdf"}:
        try: import cairosvg
        except ImportError: die("falta cairosvg: pip install cairosvg --break-system-packages")
        if "png" in fm:
            sc = min(2.0, 9000 / G["W"])
            cairosvg.svg2png(bytestring=svg.encode("utf-8"), write_to=base + "-diagrama-flujo" + sfx + ".png", scale=sc, background_color="#FFFFFF"); out.append("png")
        if "pdf" in fm:
            cairosvg.svg2pdf(bytestring=svg.encode("utf-8"), write_to=base + "-diagrama-flujo" + sfx + ".pdf"); out.append("pdf")
    if "bpmn" in fm:
        open(base + sfx + ".bpmn", "w", encoding="utf-8").write(render_bpmn(spec, lanes, nodes, byid, fases, phase_of, flows, G, R_)); out.append("bpmn")
    if "md" in fm:
        open(base + "-validacion.md", "w", encoding="utf-8").write(render_md(spec, lanes, nodes)); out.append("md")
    print(f"OK {spec['codigo']}: {len(nodes)} nodos, {len(lanes)} carriles, {len(fases or [])} fases, {G['W']}x{G['H']} px -> {', '.join(out)} en {args.salida}")

if __name__ == "__main__":
    main()
