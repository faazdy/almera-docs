# Specs de ejemplo (y pruebas de regresión)

| Spec | Modo | Qué demuestra |
|---|---|---|
| `pr-016-ris.json` | automático | 5 fases verticales, 3 carriles, 23 pasos apilados de a 2, sin decisiones, notas amarillas. |
| `pr-003-gri.json` | manual | 2 carriles, 3 decisiones (Sí/No), retorno a la actividad 1, 3 eventos Fin, ramas en fila inferior. |
| `pr-004-adm.json` | automático (con `--comentarios`) | 6 fases con letras (A–F, numeración que reinicia: pasos A1…F2), 9 carriles, un Inicio/Fin por fase (flujos independientes), 13 notas de revisión. |
| `pr-007-gri.json` | manual | 4 carriles, decisión con rama Sí en fila inferior que reconecta, cruces de carril. |

```bash
for s in pr-016-ris pr-003-gri pr-007-gri; do
  python3 scripts/generar_diagrama.py assets/specs/$s.json --salida /tmp/prueba/$s
done
```
Fuentes reales: Capital Salud EPS-S (PR-016-RIS V1.0-2026, PR-003-GRI V4.0-2026, PR-007-GRI V2.0-2026).
